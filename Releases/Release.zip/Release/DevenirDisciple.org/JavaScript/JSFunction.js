if (window.top === window.self){
  window.top.location.replace('../Menu.php');
}
